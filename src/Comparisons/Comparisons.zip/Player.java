package Comparisons;

public class Player implements Comparable<Player> {

    String firstname;
    String lastname;
    int age;
    int goals;
    int assists;
    int appearances;
    public double goalsToGameRatio;


    public Player(String firstname, String lastname, int age, int goals, int assists, int appearances){
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.goals = goals;
        this.assists = assists;
        this.appearances = appearances;
        this.goalsToGameRatio = Math.round(((double) goals / (double) appearances)*100.00)/100.00;
    }


    //Solution
    @Override
    public int compareTo(Player p){
        return this.lastname.compareTo(p.lastname);
    }

    public String toString(){
        return firstname + " " + lastname + " | " + "Age: " + age + " | " + "Goals: " + goals + " | " + "Assists: " + assists + " | " + "Appearances: " + appearances + " | " + " Goals per game: " + goalsToGameRatio;
    }
}
